# Matric Number: HC20200101090

# Student Record
## This Application handles students record.
### The functionalities included are:
- Create Student Record
- Edit Student Record
- View Student's Record
- Delete Student's Record

[Repository URL]
(https://www.github.com/DREAMLAND/HC20200101090)

