Student Record using CRUD functions

1. Import the .sql file to the wampserver/xampp/lampp database
3. Add Student Record
4. view Student Record
5. Edit Student Record
6. Delete a student record



[SIMS]
(https://www.github.com/DREAMLAND/SIMS)